import { Suspense, lazy } from 'react';
import { Navigate } from 'react-router-dom';

import SuspenseLoader from 'src/components/SuspenseLoader';

const Loader = (Component) => (props) =>
  (
    <Suspense fallback={<SuspenseLoader />}>
      <Component {...props} />
    </Suspense>
  );

// Dashboards
const Holidays = Loader(lazy(() => import('src/RITeSchool/student/holidays/Holidays')));
const Tdashboard = Loader(lazy(() => import('src/RITeSchool/student/Tdashboard/Tdashboard')));
const Practice = Loader(lazy(()=> import ('src/RITeSchool/student/Practice/Practice')));


const studentRoutes = [
  {
    path: '/',
    element: <Navigate to="holidays" replace />
  },
  {
    path: 'holidays',
    element: <Holidays />
  },
  {
    path: 'Tdashboard',
    element: <Tdashboard />
  },

  {
    path: 'Practice',
    element: <Practice />
  },
 


 
];

export default studentRoutes;
