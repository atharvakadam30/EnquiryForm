export interface GetHolidayListResult {
    EndDate:    string;
    Name:       string;
    Standards:  string;
    StartDate:  string;
    ToatalDays: string;
}