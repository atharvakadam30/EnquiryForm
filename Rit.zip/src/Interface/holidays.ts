export default interface IHolidays{
    "asAcademicYearId":string,
    "asSchoolId":string,
    "asStandardId":string,
    "asDivisionId":string,

}

