import React from 'react';
import Card11 from 'src/library/Card/Card11';
import {Box,IconButton} from '@mui/material'
function Practice() {

    const items = [
        {
            Title: 'attandace attandace attandace',
            Text1: 'mr. name',
            Text2: '30 june',
            BGColor: 'red'
          },
          {
            Title: 'School School School',
            Text1: 'mr. abc',
            Text2: '3 Nov',
            BGColor: 'green'
          },
          {
            Title: 'School School School',
            Text1: 'mr. cdf',
            Text2: '3 Nov',
            BGColor: 'green'
          },
        ]
  return (
    <Box sx={{mt:"30px"}}>
     
     {items.map((item, index) => (
     <Card11 key={index}
     Title={item.Title}
     Text1={item.Text1}
     Text2={item.Text2}
     BGColor={item.BGColor}
     />
     ))}
    </Box>
  )
}

export default Practice

