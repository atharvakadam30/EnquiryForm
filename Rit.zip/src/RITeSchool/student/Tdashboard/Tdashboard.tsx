import React from 'react';
import {
  Paper,
  Grid,
  Container,
  IconButton,
  Typography,
  Box
} from '@mui/material';
import AssignmentIcon from '@mui/icons-material/Assignment';
import Card4 from "src/library/Card/Card4";

import AccessTimeFilledIcon from '@mui/icons-material/AccessTimeFilled';
import AddPhotoAlternateIcon from '@mui/icons-material/AddPhotoAlternate';
import AssessmentIcon from '@mui/icons-material/Assessment';
import AddCommentIcon from '@mui/icons-material/AddComment';

function Tdashboard() {
  const items = [
    {
      Text: 'shcool',
      Color: '#81c784',
      iconColor: '#8d6e63',
      Icon: AssignmentIcon,
      Link:"student/Tdashboard"
    },
    {
      Text: 'massege',
      Color: '#ef5350',
      iconColor: '#ba68c8',
      Icon: AccessTimeFilledIcon,
      Link:"RITeSchool/student/holiday"
    },
    {
      Text: 'attendace',
      Color: '#90a4ae',
      iconColor: '#ef5350',
      Icon: AddPhotoAlternateIcon,
      Link:"student/schoolnotice"
    },
    {
      Text: 'homework',
      Color: '#fff176',
      iconColor: '#ff80ab',
      Icon: AssessmentIcon,
      Link:"student/schoolnotice"
    },
    {
      Text: 'teacher',
      Color: '#f48fb1',
      iconColor: '#81c784',
      Icon: AssessmentIcon,
      Link:"student/schoolnotice"
    },
    {
      Text: 'Gallery',
      Color: '#f48fb1',
      iconColor: '#ffe0b2',
      Icon: AssessmentIcon,
      Link:"student/schoolnotice"
    },
    {
      Text: 'photo',
      Color: '#fff59d',
      iconColor: '#81c784',
      Icon: AssessmentIcon,
      Link:"student/schoolnotice"
    },
    {
      Text: 'Mobile',
      Color: '#ff8a65',
      iconColor: '#ffc107',
      Icon: AssessmentIcon,
      Link:"student/schoolnotice"
    },
    {
      Text: 'App',
      Color: '#bcaaa4',
      iconColor: '#81c784',
      Icon: AssessmentIcon,
      Link:"student/schoolnotice"
    },
    {
      Text: 'Hp',
      Color: '#90caf9',
      iconColor: '#dce775',
      Icon: AssessmentIcon,
      Link:"student/schoolnotice"
    }

  ];
  return (
    <>
     <Card4 items={items} rowsCol="5"  />
     
    </>
  );
}

export default Tdashboard;
