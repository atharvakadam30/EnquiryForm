import React from 'react'

function Holidays() {
  return (
    <div>Holidays</div>
  )
}

export default Holidays